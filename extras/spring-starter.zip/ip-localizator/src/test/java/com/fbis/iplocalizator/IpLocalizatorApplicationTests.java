package com.fbis.iplocalizator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpLocalizatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
