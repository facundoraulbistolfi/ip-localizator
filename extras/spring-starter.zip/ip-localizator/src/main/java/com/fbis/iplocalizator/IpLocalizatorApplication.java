package com.fbis.iplocalizator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpLocalizatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpLocalizatorApplication.class, args);
	}

}
