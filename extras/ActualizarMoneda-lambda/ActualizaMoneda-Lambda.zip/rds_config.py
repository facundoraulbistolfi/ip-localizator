#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "omEPALfrznAn8N0RIZzw"
db_name = "iplocalizator"